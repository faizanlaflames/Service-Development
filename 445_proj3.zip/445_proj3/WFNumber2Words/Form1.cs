﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFNumber2Words
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Number2WordsService.Number2WordsClient client = new Number2WordsService.Number2WordsClient();
            textBox1.Text = client.GetData(0);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Number2WordsService.Number2WordsClient client = new Number2WordsService.Number2WordsClient();
            textBox1.Text = client.GetData(1);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Number2WordsService.Number2WordsClient client = new Number2WordsService.Number2WordsClient();
            textBox1.Text = client.GetData(2);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Number2WordsService.Number2WordsClient client = new Number2WordsService.Number2WordsClient();
            textBox1.Text = client.GetData(3);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Number2WordsService.Number2WordsClient client = new Number2WordsService.Number2WordsClient();
            textBox1.Text = client.GetData(4);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Number2WordsService.Number2WordsClient client = new Number2WordsService.Number2WordsClient();
            textBox1.Text = client.GetData(5);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Number2WordsService.Number2WordsClient client = new Number2WordsService.Number2WordsClient();
            textBox1.Text = client.GetData(6);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Number2WordsService.Number2WordsClient client = new Number2WordsService.Number2WordsClient();
            textBox1.Text = client.GetData(7);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Number2WordsService.Number2WordsClient client = new Number2WordsService.Number2WordsClient();
            textBox1.Text = client.GetData(8);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Number2WordsService.Number2WordsClient client = new Number2WordsService.Number2WordsClient();
            textBox1.Text = client.GetData(9);

        }
    }
}
