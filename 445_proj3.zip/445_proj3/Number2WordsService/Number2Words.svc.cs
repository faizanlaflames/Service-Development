﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Collections;


namespace Number2WordsService
{
   
    public class Service1 : INumber2Words
    {
        public string GetData(int value)
        {
            //NumberWord oNumberWord = new NumberWord();
            var numberWords = new List<NumberWord>() {
                new NumberWord(){ InputValue = 0, StringValue="0"},
                new NumberWord(){ InputValue = 1, StringValue="1"},
                new NumberWord(){ InputValue = 2, StringValue="Two"},
                new NumberWord(){ InputValue = 3, StringValue="Three"},
                new NumberWord(){ InputValue = 4, StringValue="Four"},
                new NumberWord(){ InputValue = 5, StringValue="Five"},
                new NumberWord(){ InputValue = 6, StringValue="Six"},
                new NumberWord(){ InputValue = 7, StringValue="Seven"},
                new NumberWord(){ InputValue = 8, StringValue="Eight"},
                new NumberWord(){ InputValue = 9, StringValue="Nine"}
                
            };

            //get all students whose name is Bill
            var result = from nw in numberWords
                         where nw.InputValue == value
                         select nw;

            string displayString="0";
            foreach (var resultStriing in result)
            {
               displayString = resultStriing.StringValue;
            }

            return  displayString;
        }

      
    }
}
