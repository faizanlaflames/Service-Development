﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WFWebDownloading
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string strUrl = textBox1.Text;
                WebDownloadingService.WebDownloadingClient client = new WebDownloadingService.WebDownloadingClient();
                var textContainer = client.getRandom(1);
                string fileName = "URLTextContainer.txt";
                client.PutStringToFile(fileName, textContainer);
                label2.Text = "URL Text is sucessfully saved in text file.";

            }
            catch (Exception ex)
            {
                label2.Text = ex.Message;
            }
           


        }
    }
}
