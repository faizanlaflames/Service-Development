﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.IO;
using System.Web;
using System.Xml.Linq;
using System.Net;

namespace WebDownloading
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IWebDownloading
    {
        public string getRandom(int len)
        {
            CompositeType oCompositeType = new CompositeType();
            string baseURL = oCompositeType.StringValue;
            string fullURL = baseURL + Convert.ToSingle(len);
            Uri ServivrUri = new Uri(fullURL); // convert string to Uri type
            WebClient proxy = new WebClient(); // Creating a proxy
            byte[] abc = proxy.DownloadData(ServivrUri); //byte[] type
            string str = System.Text.UTF8Encoding.UTF8.GetString(abc);//convert to string
            XElement xmlroot = XElement.Parse(str); 
            string txtContent = ((XElement)(xmlroot)).Value;
            return txtContent;
        }
        public void PutStringToFile(string fileName, string value)
        {
            string fLocation = Path.Combine(HttpRuntime.AppDomainAppPath, @"App_Data"); // From server root to current
            fLocation = Path.Combine(fLocation, fileName); // From current to App_Data
            if (File.Exists(fLocation))
            {
                File.Delete(fLocation);
            }
            using (StreamWriter sw = File.CreateText(fLocation))
            {
                var urlText= sw;
            }
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}
